//
//  RecipeTableViewCell.swift
//  FinalTest
//
//  Created by Ravi  on 2023-08-16.
//

import UIKit

class RecipeTableViewCell: UITableViewCell {

    @IBOutlet var thumbView: UIImageView!
    
    @IBOutlet var titleLabel: UILabel!
    
    @IBOutlet var originLabel: UILabel!
    
    @IBOutlet var calorieCountLabel: UILabel!
    
    
}
