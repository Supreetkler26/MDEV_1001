package com.example.android_assignment;

import android.app.Activity;

public class NewCourseActivity extends Activity {
}
