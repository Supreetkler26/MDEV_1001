package com.example.android_assignment.Modal;

public class MovieModal {
    public String image_path;
    public String courseName;
    public Integer movieID;
    public String title;
    public String studio;
    public String genres;
    public String directors;
    public String writers;
    public String actors;
    public Integer year;
    public Integer length;
    public String shortDescription ;
    public String mpaRating;
    public Float criticsRating;
}
