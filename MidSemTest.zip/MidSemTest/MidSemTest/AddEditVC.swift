//
//  AddEditVC.swift
//  MidSemTest
//
//  Created by Ravi  on 2023-06-24.
//

import Foundation
import UIKit

class AddEditVC:UIViewController {
    
    @IBOutlet weak var addEditLabel: UILabel!
    @IBOutlet weak var updateBtn: UIButton!
    
    
    @IBOutlet weak var titleText: UITextField!
    
    @IBOutlet weak var authorText: UITextField!
    
    @IBOutlet weak var genresText: UITextField!
    
    @IBOutlet weak var countryText: UITextField!
    
    @IBOutlet weak var dateText: UITextField!
    
    @IBOutlet weak var publisherText: UITextField!
    
    @IBOutlet weak var pageCount: UITextField!
    
    @IBOutlet weak var languageText: UITextField!
    
    @IBOutlet weak var isbnText: UITextField!
    
    @IBOutlet weak var imageURL: UITextField!
    
    @IBOutlet weak var summaryText: UITextView!
    
    
    var book : Book?
    var dataViewController : DataViewController?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let book = book{
            
            titleText.text = book.title
            authorText.text = book.author
            genresText.text = book.genres
            countryText.text = book.country
            publisherText.text = book.publisher
            dateText.text = book.publicationdate
            pageCount.text = book.pagecount
            languageText.text = book.language
            isbnText.text = book.isbn
            imageURL.text = book.imgurl
            summaryText.text = book.shortdescription
        }
        else
        {
            addEditLabel.text = "Add Book"
            updateBtn.setTitle("Add", for: .normal)
            
        }
        
        
    }
    
    
    @IBAction func cancelButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func updateButton(_ sender: Any) {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else
        {
            return
        }
        
        let context = appDelegate.persistentContainer.viewContext
        
        if let book = book
        {
            
            book.title = titleText.text
            book.author = authorText.text
            book.genres = genresText.text
            book.country = countryText.text
            book.publisher = publisherText.text
            book.publicationdate = dateText.text
            book.pagecount = pageCount.text
            book.language = languageText.text
            book.isbn = isbnText.text
            book.imgurl = imageURL.text
            book.shortdescription = summaryText.text
        } else {
            
            let newBook = Book(context: context)
            newBook.title = titleText.text
            newBook.author = authorText.text
            newBook.genres = genresText.text
            newBook.country = countryText.text
            newBook.publisher = publisherText.text
            newBook.publicationdate = dateText.text
            newBook.pagecount = pageCount.text
            newBook.language = languageText.text
            newBook.isbn = isbnText.text
            newBook.imgurl = imageURL.text
            newBook.shortdescription = summaryText.text
        }
        
        do {
            
            try context.save()
            dataViewController?.fetchData()
            dismiss(animated: true, completion: nil)
            
        } catch {
            print("Failed to save data: \(error)")
        }
        
    }
    
    
}
