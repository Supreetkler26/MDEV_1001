//
//  BookTableViewCell.swift
//  MidSemTest
//
//  Created by Ravi  on 2023-06-24.
//

import Foundation
import UIKit

class BookTableViewCell:UITableViewCell{
    
    @IBOutlet weak var titleLabel: UITextField!
    
    @IBOutlet weak var authorLabel: UITextField!
    
    @IBOutlet weak var bookImage: UIImageView!
}
