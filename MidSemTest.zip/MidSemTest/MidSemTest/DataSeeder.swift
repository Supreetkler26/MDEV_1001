import Foundation
import UIKit
import CoreData

func seedData()
{
    guard let url = Bundle.main.url(forResource: "Books", withExtension: "json") else {
        print("JSON file not found.")
        return
        
    }
    
    guard let data = try? Data(contentsOf: url) else
    {
        print("Failed to read JSON file.")
        return
    }
    
    guard let jsonArray = try? JSONSerialization.jsonObject(with: data, options: []) as? [[String: Any]] else
    {
        print("Failed to parse JSON.")
        return
    }
    
    guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else
    {
        print("AppDelegate not found.")
        return
    }
    
    let context = appDelegate.persistentContainer.viewContext
    
    for jsonObject in jsonArray
    {
        let book = Book(context: context)
        
        book.bookID = jsonObject["bookID"] as? Int16 ?? 0
        book.title = jsonObject["Title"] as? String
        book.author = jsonObject["Author"] as? String
        book.genres = jsonObject["Genres"] as? String
        book.country = jsonObject["Country"] as? String
        book.publicationdate = jsonObject["PublicationDate"] as? String
        book.publisher = jsonObject["Publisher"] as? String
        book.pagecount = jsonObject["PageCount"] as? String
        book.language = jsonObject["Language"] as? String
        book.shortdescription = jsonObject["ShortDescription"] as? String
        book.isbn = jsonObject["ISBN"] as? String
        book.imgurl = jsonObject["imgURL"] as? String
        
        // Save the context after each book is created
        do {
            try context.save()
        } catch {
            print("Failed to save book: \(error)")
        }
    }
    
    print("Data seeded successful")
    
          

}
