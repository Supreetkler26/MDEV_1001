//
//  ViewController.swift
//  MidSemTest
//
//  Created by Ravi  on 2023-06-24.
//

import UIKit
import CoreData

class DataViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    var books: [Book] = []
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        fetchData()
    }
    
    func fetchData()
    {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else
        {
            return
        }
        
        let context = appDelegate.persistentContainer.viewContext
        
        let fetchRequest: NSFetchRequest<Book> = Book.fetchRequest()
        
        do {
            books = try context.fetch(fetchRequest)
            tableView.reloadData()
        } catch {
            print("Failed to fetch data: \(error)")
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return books.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BookCell", for: indexPath) as! BookTableViewCell
        
        let book = books[indexPath.row]
        
        cell.titleLabel?.text = book.title
        cell.authorLabel?.text = book.author
        //        cell.bookImageview.image = "\(book.imgurl)"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        performSegue(withIdentifier: "AddEditSegue", sender: indexPath)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete
        {
            let book = books[indexPath.row]
            ShowDeleteConfirmationAlert(for: book) { confirmed in
                if confirmed
                {
                    self.deleteMovie(at: indexPath)
                }
            }
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "AddEditSegue"
        {
            if let addEditVC = segue.destination as? AddEditVC
            {
                addEditVC.dataViewController = self
                if let indexPath = sender as? IndexPath
                {
                    let book = books[indexPath.row]
                    addEditVC.book = book
                } else {
                    addEditVC.book = nil
                }
            }
        }
    }
    
    @IBAction func addButton(_ sender: Any) {
        performSegue(withIdentifier: "AddEditSegue", sender: nil)
    }
    
    
    func ShowDeleteConfirmationAlert(for book: Book, completion: @escaping (Bool) -> Void)
    {
        let alert = UIAlertController(title: "Delete Book", message: "Are you sure you want to delete this movie?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in
            completion(false)
        })
        
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive) { _ in
            completion(true)
        })
        
        present(alert, animated: true, completion: nil)
    }
    
    func deleteMovie(at indexPath: IndexPath)
    {
        let book = books[indexPath.row]
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else
        {
            return
        }
        
        let context = appDelegate.persistentContainer.viewContext
        context.delete(book)
        
        do {
            try context.save()
            books.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } catch {
            print("Failed to delete movie: \(error)")
        }
        
    }
}
