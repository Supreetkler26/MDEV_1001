//
//  ViewController.swift
//  Assignment_3_CRUD
//
//  Created by Ravi  on 2023-07-20.
//

import UIKit
import Foundation


class SearchMoviesVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var tableView: UITableView!
    
    var movies: [Movie] = []
    var filteredMovies: [Movie] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchMovieData(with: "Titanic")
        searchBarCancelButtonClicked(searchBar)
        
    }
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
           if let searchText = searchBar.text {
               fetchMovieData(with: searchText)
           }
           searchBar.resignFirstResponder()
       }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
           searchBar.text = ""
           filteredMovies.removeAll()
//        fetchMovieData(with: "Titanic")
           tableView.reloadData()
        
       }
    
    
    func filterMovies(searchText: String) {
        if searchText.isEmpty {
            filteredMovies = movies
        } else {
            filteredMovies = movies.filter { $0.title.lowercased().contains(searchText.lowercased()) }
        }

        tableView.reloadData()
    }

    
    func fetchMovieData(with searchText: String) {
           let apiKey = "49add373"
           let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)

           let urlString = "https://www.omdbapi.com/?apikey=\(apiKey)&s=\(query)"

           guard let url = URL(string: urlString) else {
               print("Invalid URL")
               return
           }

           let session = URLSession.shared
           let task = session.dataTask(with: url) { [weak self] data, response, error in
               guard let self = self else { return }

               if let error = error {
                   print("Error: \(error)")
                   return
               }

               guard let data = data else {
                   print("No data received")
                   return
               }

               do {
                   if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any], let movieList = json["Search"] as? [[String: Any]] {
                       // Clear existing data
                       print(json)
                       self.movies.removeAll()

                       // Parse the JSON response and store the data in your array
                       for movieData in movieList {
                           if let movie = Movie(json: movieData) {
                               self.movies.append(movie)
                           }
                       }

                       // Reload the table view to display the fetched data
                       DispatchQueue.main.async {
                           self.tableView.reloadData()
                       }
                   }
               } catch {
                   print("Error parsing JSON: \(error)")
               }
           }

           task.resume()
       }


    @IBAction func searchButton(_ sender: Any){
        if let searchText = searchBar.text {
            filterMovies(searchText: searchText)
        }
        searchBar.resignFirstResponder()
    }
    
    func downloadPosterImage(for url: URL, completion: @escaping (UIImage?) -> Void) {
           DispatchQueue.global().async {
               if let data = try? Data(contentsOf: url), let image = UIImage(data: data) {
                   completion(image)
               } else {
                   completion(nil)
               }
           }
       }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return searchBarIsEmpty ? movies.count : filteredMovies.count
//        return movies.count
        }
    
    var searchBarIsEmpty: Bool {
            return searchBar.text?.isEmpty ?? true
        }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "MovieCell", for: indexPath) as! MovieTableViewCell
           let movie = searchBarIsEmpty ? movies[indexPath.row] : filteredMovies[indexPath.row]
        
        cell.titleLabel.text = movie.title
        cell.typeLabel.text = movie.type
        cell.yearLabel.text = movie.year
        cell.imdbLabel.text = movie.imdb

        if let posterURL = movie.poster {
            downloadPosterImage(for: posterURL) { image in
                DispatchQueue.main.async {
                    cell.posterView.image = image
                }
            }
        } else {
            // Handle the case when the index is out of range
            cell.titleLabel.text = "N/A"
            cell.typeLabel.text = "N/A"
            cell.yearLabel.text = "N/A"
            cell.imdbLabel.text = "N/A"
            cell.posterView.image = UIImage(named: "default_poster")
        }

        return cell
    }

    
   /*
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//            let selectedMovie = movies[indexPath.row]
//
//            // For example, showing a simple alert:
//        let alertController = UIAlertController(title: selectedMovie.title, message: "Year: \(selectedMovie.year)\nType: \(selectedMovie.type)\nIMDB: \(selectedMovie.imdb)", preferredStyle: .alert)
//
//            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
//            alertController.addAction(okAction)
//            present(alertController, animated: true, completion: nil)
        
        let selectedMovie = searchBarIsEmpty ? movies[indexPath.row] : filteredMovies[indexPath.row]
           performSegue(withIdentifier: "ShowDetails", sender: selectedMovie)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowDetails", let movieDetailsVC = segue.destination as? MovieDetailVC {
            if let selectedMovie = sender as? Movie {
                movieDetailsVC.movie = selectedMovie
            }
        }
    }
    */
    
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let selectedMovie = searchBarIsEmpty ? movies[indexPath.row] : filteredMovies[indexPath.row]
//        if let posterURL = selectedMovie.poster {
//            downloadPosterImage(for: posterURL) { image in
//                DispatchQueue.main.async {
//                    self.performSegue(withIdentifier: "ShowDetails", sender: (selectedMovie, image))
//                }
//            }
//        } else {
//            self.performSegue(withIdentifier: "ShowDetails", sender: (selectedMovie, indexPath))
//        }
//    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedMovie = searchBarIsEmpty ? movies[indexPath.row] : filteredMovies[indexPath.row]
        if let posterURL = selectedMovie.poster {
            downloadPosterImage(for: posterURL) { image in
                DispatchQueue.main.async {
                    self.performSegue(withIdentifier: "ShowDetails", sender: (selectedMovie, image))
                }
            }
        } else {
            // If the poster URL is nil, you can pass a placeholder image or nil as the image parameter
            self.performSegue(withIdentifier: "ShowDetails", sender: (selectedMovie, nil as UIImage?))
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowDetails", let movieDetailsVC = segue.destination as? MovieDetailVC {
            if let data = sender as? (movie: Movie, image: UIImage?) {
                movieDetailsVC.movie = data.movie
                movieDetailsVC.posterImage = data.image
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130.0
    }
}

