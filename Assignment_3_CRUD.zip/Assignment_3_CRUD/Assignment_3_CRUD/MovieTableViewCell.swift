//
//  MovieViewCell.swift
//  Assignment_3_CRUD
//
//  Created by Ravi  on 2023-07-20.
//

import Foundation
import UIKit

class MovieTableViewCell : UITableViewCell {
    
    
    @IBOutlet var posterView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var typeLabel: UILabel!
    
    @IBOutlet weak var yearLabel: UILabel!
    
    @IBOutlet weak var imdbLabel: UILabel!
    
    
    
    }

/*
import UIKit
import Alamofire

class ViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    var movies: [Movie] = [] // Replace Movie with your custom data model for storing movie information

    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.dataSource = self
        tableView.delegate = self

        // Call the function to fetch movie data
        fetchMovieData()
    }

    func fetchMovieData() {
        let apiKey = "YOUR_OMDB_API_KEY"
        let query = "movie_title_here" // Replace with the movie title you want to search

        let urlString = "http://www.omdbapi.com/?apikey=\(apiKey)&s=\(query)"

        AF.request(urlString).responseJSON { response in
            switch response.result {
            case .success(let value):
                if let json = value as? [String: Any], let movieList = json["Search"] as? [[String: Any]] {
                    // Clear existing data
                    self.movies.removeAll()

                    // Parse the JSON response and store the data in your array
                    for movieData in movieList {
                        if let movie = Movie(json: movieData) { // Replace Movie with your custom data model initializer
                            self.movies.append(movie)
                        }
                    }

                    // Reload the table view to display the fetched data
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MovieCell", for: indexPath) as! MovieTableViewCell
        let movie = movies[indexPath.row]
        cell.titleLabel.text = movie.title
        cell.yearLabel.text = movie.year
        // Set other properties of the custom cell based on your data model

        return cell
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedMovie = movies[indexPath.row]
        // Perform any action when a row is selected, for example, display more details about the selected movie.
        // You can push a new view controller or show a UIAlertController with more information.
        
        // For example, showing a simple alert:
        let alertController = UIAlertController(title: selectedMovie.title, message: "Year: \(selectedMovie.year)\nType: \(selectedMovie.type)", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
}
*/
