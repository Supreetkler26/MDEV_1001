import UIKit

class Movie {
    var title: String
    var year: String
    var type: String
    var imdb: String
    var poster: URL? 

    init?(json: [String: Any]) {
        guard let title = json["Title"] as? String,
              let year = json["Year"] as? String,
              let type = json["Type"] as? String,
              let imdb = json["imdbID"] as? String,
              let posterString = json["Poster"] as? String,
              let posterURL = URL(string: posterString)
        else {
            return nil
        }

        self.title = title
        self.year = year
        self.type = type
        self.imdb = imdb
        self.poster = posterURL
    }
}
