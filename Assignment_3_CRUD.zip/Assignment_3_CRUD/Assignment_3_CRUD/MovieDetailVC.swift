//
//  MovieDetailVC.swift
//  Assignment_3_CRUD
//
//  Created by Ravi  on 2023-07-21.
//

import UIKit

class MovieDetailVC: UIViewController {
    
    @IBOutlet var posterImageView: UIImageView!
    
    @IBOutlet var movieTitleTextField: UITextField!
    
    @IBOutlet var yearTextField: UITextField!
    
    @IBOutlet var typeTextField: UITextField!
    
    @IBOutlet var imdbTextField: UITextField!
    
    @IBOutlet var descriptionTextView: UITextView!
    
    var movie: Movie?
    var posterImage: UIImage?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
  
        configureView()
        
//
//        if let movie = movie {
//            movieTitleTextField.text = movie.title
//            yearTextField.text = movie.year
//            typeTextField.text = movie.type
//            imdbTextField.text = movie.imdb
//            posterImageView.image = posterImage
//        }
    }
    
    
    func configureView() {
            if let movie = movie {
                movieTitleTextField.text = movie.title
                yearTextField.text = movie.year
                typeTextField.text = movie.type
                imdbTextField.text = movie.imdb
            }

            if let posterImage = posterImage {
                posterImageView.image = posterImage
            } else {
                posterImageView.image = UIImage(named: "default_poster")
        }
    }
    
    

    @IBAction func backButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    

}
