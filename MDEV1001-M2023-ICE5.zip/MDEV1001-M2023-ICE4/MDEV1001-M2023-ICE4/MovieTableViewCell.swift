//
//  MovieTableViewCell.swift
//  MDEV1001-M2023-ICE4
//
//  Created by Ravi  on 2023-06-11.
//

import Foundation

import UIKit

class MovieTableViewCell: UITableViewCell
{
        
    
    @IBOutlet weak var titleLabel: UITextField!
    
    @IBOutlet weak var studioLabel: UILabel!
    
    //@IBOutlet weak var ratingLabel: UITextField!
}
